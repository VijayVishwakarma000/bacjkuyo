export const userData = [
  {
    id:'023123',
    Firstname: "Doggie",
    Lastname: "singh",
    membershipStatus: "Active",
    validity:200,
    phonenumber:200-200-242,
    age:20,
    height:200,
    weight:450,
    gender:'male',
    goals:[0,1,2,3,4,5]
  },
  {
    id:'023123',
    Firstname: "oggie",
    Lastname: "shah",
    membershipStatus: "Active",
    validity:200,
    phonenumber:200-200-242,
    age:20,
    height:200,
    weight:450,
    gender:'male',
    goals:[0,1,2,3,4,5]
  },
  {
    id:'023123',
    Firstname: "bhupendra",
    Lastname: "jogi",
    membershipStatus: "Active",
    validity:200,
    phonenumber:200-200-242,
    age:20,
    height:200,
    weight:450,
    gender:'male',
    goals:[0,1,2,3,4,5]
  },
  



];
