import React, { useState } from "react";
import { NavLink } from "react-router-dom";
import { FaMicrosoft, FaPlus, FaUserMinus } from "react-icons/fa";
import { FaPersonRunning, FaUser } from "react-icons/fa6";
import { BsArrowLeftShort } from "react-icons/bs";

//components
const Sidebar = (e: any) => {
  const [Open, setOpen] = useState(true);
  const [Active, setActive] = useState(false)
  const [ActiveClass, setActiveClass] = useState("")

  const checkActive = (e)=>{
    let x = e.currentTarget.classList.contains('active')
    if(x){
      setActive(true)
      console.log(Active)
    }


  }
       
  const navlinks = [
    {
      title: "Dashboard",
      route: "/dashboard",
      icon: <FaMicrosoft />,
    },
    {
      title: "Create User",
      route: "/createuser",
      icon: <FaPlus />,
    },
    {
      title: "active users",
      route: "/activeuser",
      icon: <FaUser />,
    },
    {
      title: "Check In",
      route: "/checkin",
      icon: <FaPersonRunning />,
    },
    {
      title: "past",
      route: "/past",
      icon: <FaUserMinus />,
    },
  ];


  return (
    <>
      <div className="flex">
        <div
          className={`bg-slate-600 p-5 pt-8 h-screen w-72 ${
            Open ? "w-72" : "w-20"
          } duration-300 relative`}
        >
          <BsArrowLeftShort
            onClick={() => setOpen(!Open)}
            className={`bg-white ${!Open && "rotate-180"}  rounded-full
            text-3xl -right-4 top-9 border cursor-pointer border-stone-50 absolute duration-300 duration-250 "} `}
          />
          <div className="inline-flex items-center uppercase ">
            <FaUser
              className={`p-2 bg-zinc-950 text-white rounded text-4xl block float-left mr-2 cursor-pointer duration-500 ${
                Open && "rotate-[360deg]"
              } `}
            />
            <h1
              className={`text-white  origin-left font-medium text-2xl ${
                !Open && "scale-0"
              } duration-300 `}
            >
              Logo
            </h1>
          </div>

          <ul className="pt-2">
            {navlinks.map((elem, id) => (
              <NavLink   onClick={checkActive}  to={elem.route}    key={id} >
                <li  className={` ${Active ? "bg-slate-200 text-slate-900" : "   "}hover:text-slate-800 hover:bg-slate-200   text-gray-200  text-sm  gap-x-4 rounded-md mt-4  flex flex-row item-center  cursor-pointer p-2  `} to={""}>
                  <span className={` ${Active ? "bg-slate-200 text-slate-900" : "   "} text-2xl block float-left `}>
                    {elem.icon}
                   
                  </span>
                  <span
                    className={`${Active ? " text-slate-900" : "   "} font-medium text-base  flex-1 duration-200 ${
                      !Open && "hidden invisible "
                    }  `}
                  >
                    {elem.title}
                  </span>
                </li>
              </NavLink>
            ))}
          </ul>
        </div>
      </div>
    </>
  );
};

export default Sidebar;
